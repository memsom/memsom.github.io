<pre>
Title: Converting an SVG in to a Xaml path
Published: 4/3/2021
Tags: 
- csharp
- xaml
- programming
- svg
</pre>
---
# How do you convert an SVG to a Xaml path?
So - asked by a colleague how to do this, I made the following SVG:

![Star SVG Image](images/star.svg)

This is a 2 layer SVG, with the circle being on one layer and the star on the second. I created the image in Inkscape - which is pretty easy to use and this took, maybe 5 minutes. Inkscape can export to Xaml Path. So I ended up with the following [Xaml](images/star.xaml):

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!--This file is NOT compatible with Silverlight-->
<Viewbox xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Stretch="Uniform">
  <Canvas Name="svg8" Width="63.809044" Height="61.541187">
    <Canvas.RenderTransform>
      <TranslateTransform X="0" Y="0"/>
    </Canvas.RenderTransform>
    <Canvas.Resources/>
    <!--Unknown tag: sodipodi:namedview-->
    <!--Unknown tag: metadata-->
    <Canvas Name="layer1">
      <Canvas.RenderTransform>
        <TranslateTransform X="-23.657977" Y="-29.616311"/>
      </Canvas.RenderTransform>
      <Ellipse xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Canvas.Left="24.2" Width="62.7" Canvas.Top="30.1" Height="60.5" Name="path815" Fill="#FF00FF00" StrokeThickness="1.06500006" Stroke="#FF000000" StrokeMiterLimit="4" StrokeLineJoin="Bevel" StrokeStartLineCap="Round" StrokeEndLineCap="Round"/>
    </Canvas>
    <Canvas Name="layer2">
      <Canvas.RenderTransform>
        <TranslateTransform X="-23.657977" Y="-29.616311"/>
      </Canvas.RenderTransform>
      <Path xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Name="path819" Fill="#FFF80000" StrokeThickness="1.06500006" Stroke="#FF000000" StrokeMiterLimit="4" StrokeLineJoin="Miter" StrokeStartLineCap="Flat" StrokeEndLineCap="Flat">
        <Path.Data>
          <PathGeometry Figures="M 54.699142 33.286335 46.106258 48.693064 29.337637 49.085603 43.902103 63.631112 34.119389 82.463766 56.30276 74.712953 77.684273 81.661961 69.497116 64.392885 82.8495 49.00534 64.540804 48.35921 Z" FillRule="NonZero"/>
        </Path.Data>
      </Path>
    </Canvas>
  </Canvas>
</Viewbox>
```
The question then is - how to use this?

## Just the Canvas
We can really just do away with everything except the `Canvas` element and its content. This is the "meat" of the path.

## Scale
The image I created is at a random size. So scaling the image is very crucial. I added a `ScaleTransform` to the outer `Canvas`, like this:
```xml
<Canvas.LayoutTransform>
    <ScaleTransform ScaleX="0.5" ScaleY="0.5" />
</Canvas.LayoutTransform>
```
## Componentize
I created a simple User control and added the basic `Canvas` and Transform to resize. I ended up with this:
```xml
<UserControl x:Class="testpathxaml.StarIcon"
             xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" 
             xmlns:d="http://schemas.microsoft.com/expression/blend/2008" 
             xmlns:local="clr-namespace:testpathxaml"
             mc:Ignorable="d">
    <Grid>
        <Canvas Name="svg8" Width="63" Height="61">
            <Canvas.RenderTransform>
                <TranslateTransform X="0" Y="0"/>
            </Canvas.RenderTransform>
            <Canvas.Resources/>
            <!--Unknown tag: sodipodi:namedview-->
            <!--Unknown tag: metadata-->
            <Canvas Name="layer1">
                <Canvas.RenderTransform>
                    <TranslateTransform X="-23.657977" Y="-29.616311"/>
                </Canvas.RenderTransform>
                <Ellipse xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Canvas.Left="24.2" Width="62.7" Canvas.Top="30.1" Height="60.5" Name="path815" Fill="#FF00FF00" StrokeThickness="1.06500006" Stroke="#FF000000" StrokeMiterLimit="4" StrokeLineJoin="Bevel" StrokeStartLineCap="Round" StrokeEndLineCap="Round"/>
            </Canvas>
            <Canvas Name="layer2">
                <Canvas.RenderTransform>
                    <TranslateTransform X="-23.657977" Y="-29.616311"/>
                </Canvas.RenderTransform>
                <Path xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Name="path819" Fill="#FFF80000" StrokeThickness="1.06500006" Stroke="#FF000000" StrokeMiterLimit="4" StrokeLineJoin="Miter" StrokeStartLineCap="Flat" StrokeEndLineCap="Flat">
                    <Path.Data>
                        <PathGeometry Figures="M 54.699142 33.286335 46.106258 48.693064 29.337637 49.085603 43.902103 63.631112 34.119389 82.463766 56.30276 74.712953 77.684273 81.661961 69.497116 64.392885 82.8495 49.00534 64.540804 48.35921 Z" FillRule="NonZero"/>
                    </Path.Data>
                </Path>
            </Canvas>
        </Canvas>
    </Grid>
</UserControl>
```
This can then be pasted in to a Window as a custom control:
```xml
<Window x:Class="testpathxaml.MainWindow"
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        xmlns:d="http://schemas.microsoft.com/expression/blend/2008"
        xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
        xmlns:local="clr-namespace:testpathxaml"
        mc:Ignorable="d"
        Title="MainWindow" Height="450" Width="800">
    <Grid>
        <local:StarIcon />
    </Grid>
</Window>
```

## Adding properties to control the content
The next step was to add some extra properties to the UserControl. These control the Fore and Back colours and the Scale.
```CSharp
public partial class StarIcon: UserControl
{
    public StarIcon()
    {
        InitializeComponent();
    }

    public double Scale
    {
        get { return (double)GetValue(ScaleProperty); }
        set { SetValue(ScaleProperty, value); }
    }

    public static readonly DependencyProperty ScaleProperty =
        DependencyProperty.Register("Scale", typeof(double), typeof(StarIcon), new PropertyMetadata(0.5));

    public Color BackColor
    {
        get { return (Color)GetValue(BackColorProperty); }
        set { SetValue(BackColorProperty, value); }
    }

    public static readonly DependencyProperty BackColorProperty =
        DependencyProperty.Register("BackColor", typeof(Color), typeof(StarIcon));

    public Color ForeColor
    {
        get { return (Color)GetValue(ForeColorProperty); }
        set { SetValue(ForeColorProperty, value); }
    }

    public static readonly DependencyProperty ForeColorProperty =
        DependencyProperty.Register("ForeColor", typeof(Color), typeof(StarIcon));

}
```
This was a proof of concept, so no frills. But the defaults could be set for the `Color`s to make the control look more appealing at design time.

Because the control needs to use these values, I added code to the Xaml to bind the values. Along the way, it became apparent that the `Path` and `Ellipse` both use a `Brush` for their Fill property, so I added in a `IValueConverter` ([Stack overflow](https://stackoverflow.com/questions/3309709/how-do-i-convert-a-color-to-a-brush-in-xaml) sourced):

```CSharp
public class ColorToSolidColorBrushValueConverter: IValueConverter
{

    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
        if(null == value)
        {
            return null;
        }

        if(value is Color)
        {
            Color color = (Color)value;
            return new SolidColorBrush(color);
        }

        Type type = value.GetType();
        throw new InvalidOperationException("Unsupported type [" + type.Name + "]");
    }

    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}
```
And added the binding to the Xaml for the UserControl:
```xml
<UserControl x:Class="testpathxaml.StarIcon"
             xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" 
             xmlns:d="http://schemas.microsoft.com/expression/blend/2008" 
             xmlns:local="clr-namespace:testpathxaml"
             mc:Ignorable="d">
    <UserControl.Resources>
        <local:ColorToSolidColorBrushValueConverter  x:Key="colorConverter"/>
    </UserControl.Resources>
    <Grid>
        <Canvas Name="svg8" Width="63" Height="61">
            <Canvas.RenderTransform>
                <TranslateTransform X="0" Y="0"/>
            </Canvas.RenderTransform>
            <Canvas.LayoutTransform>
                <ScaleTransform ScaleX="{Binding RelativeSource={RelativeSource FindAncestor, 
                                                 AncestorType={x:Type local:StarIcon}}, Path=Scale}" 
                                ScaleY="{Binding RelativeSource={RelativeSource FindAncestor, 
                                                 AncestorType={x:Type local:StarIcon}}, Path=Scale}" />
            </Canvas.LayoutTransform>
            <Canvas.Resources/>
            <Canvas Name="layer1">
                <Canvas.RenderTransform>
                    <TranslateTransform X="-23.657977" Y="-29.616311"/>
                </Canvas.RenderTransform>
                <Ellipse xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Canvas.Left="24.2" 
                         Width="62.7" Canvas.Top="30.1" Height="60.5" Name="path815" 
                         Fill="{Binding RelativeSource={RelativeSource FindAncestor, 
                                        AncestorType={x:Type local:StarIcon}}, 
                                        Path=BackColor, Converter={StaticResource colorConverter}}" 
                         StrokeThickness="1.06500006" Stroke="Black" 
                         StrokeMiterLimit="4" StrokeLineJoin="Bevel" StrokeStartLineCap="Round" StrokeEndLineCap="Round"/>
            </Canvas>
            <Canvas Name="layer2">
                <Canvas.RenderTransform>
                    <TranslateTransform X="-23.657977" Y="-29.616311"/>
                </Canvas.RenderTransform>
                <Path xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Name="path819" 
                      Fill="{Binding RelativeSource={RelativeSource FindAncestor, 
                                     AncestorType={x:Type local:StarIcon}}, 
                                     Path=ForeColor, Converter={StaticResource colorConverter}}" 
                      StrokeThickness="1.06500006" Stroke="Black" StrokeMiterLimit="4" StrokeLineJoin="Miter" 
                      StrokeStartLineCap="Flat" StrokeEndLineCap="Flat">
                    <Path.Data>
                        <PathGeometry Figures="M 54.699142 33.286335 46.106258 48.693064 29.337637 49.085603 43.902103 63.631112 34.119389 82.463766 56.30276 74.712953 77.684273 81.661961 69.497116 64.392885 82.8495 49.00534 64.540804 48.35921 Z" FillRule="NonZero"/>
                    </Path.Data>
                </Path>
            </Canvas>
        </Canvas>
    </Grid>
</UserControl>
```
And there you have it. A reusable, scalable control that allows the colours to be set independently.

- The full source is in the zip file that accoumpanied this readme.
- The original SVG is '[star.svg]((images/star.xaml))'.
- The Xaml export is '[star.xaml]((images/star.xaml))'.

## Conclusion
This technique yielded very great results. Being bindable, we can reuse this control and drive the colours and scaling through any view model or bindable context.